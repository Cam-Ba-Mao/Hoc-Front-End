   
var swiper = new Swiper(".mySwiper", {
    effect: "cards",
    grabCursor: true,
    centeredSlides: true,
    loop: true,
    cardsEffect: {
            rotate: false,
            slideShadows: false,
            perSlideOffset: 90,
            perSlideRotate: 0,
        },
    });